Server compilation : gcc Server.c -o server -lm -pthread
Client compilation : gcc Client.c -o client
